﻿namespace _2048
{
    public class SQLiteConnection
    {
    }
}